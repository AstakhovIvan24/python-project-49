### Hexlet tests and linter status:
[![Actions Status](https://github.com/AstakhovIvan24/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AstakhovIvan24/python-project-49/actions)
Brain-even link: https://asciinema.org/a/zdIDsrEd4b47no430WUAxyR3L
Brain-calc link: https://asciinema.org/a/J1OPW46gGInaMkkBElzPXV8xM
Brain-gcd link: https://asciinema.org/a/qGqLBKFgssQPJZyPZkHZW0nnt
Brain-progression link: https://asciinema.org/a/hWVzmXwfCfdXKgOVmgd1IkuU5
