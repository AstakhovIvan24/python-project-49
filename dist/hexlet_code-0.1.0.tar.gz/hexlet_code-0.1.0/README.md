### Hexlet tests and linter status:
[![Actions Status](https://github.com/AstakhovIvan24/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/AstakhovIvan24/python-project-49/actions)
https://asciinema.org/a/zdIDsrEd4b47no430WUAxyR3L
